//
//  ViewController.swift
//  DragMeDown
//
//  Created by Alfredo Uzumaki on 7/12/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func gotoNextButtonAction(_ sender: Any) {
        gotoNextController()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func gotoNextController() {
        let vc = storyboard?.instantiateViewController(withIdentifier: "NextViewController") as! NextViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overCurrentContext
        present(vc, animated: true, completion: nil)
    }
}

