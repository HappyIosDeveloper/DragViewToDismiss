//
//  NextViewController.swift
//  DragMeDown
//
//  Created by Alfredo Uzumaki on 7/12/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class NextViewController: UIViewController {
    
    @IBOutlet weak var blurBackgroundView: UIVisualEffectView!
    @IBOutlet weak var parentView: UIView!
    
    var panGestureRecognizer: UIPanGestureRecognizer?
    var originalPosition: CGPoint!
    var originalFrame:CGRect!
    var currentPositionTouched: CGPoint?
    var allowDrag = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addGestures()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        removeGustures()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setupPage()
    }
    
    func setupPage() {
        parentView.layer.cornerRadius = 20
        originalPosition = parentView.center
        originalFrame = parentView.frame
        self.view.layoutIfNeeded()
        super.viewDidLayoutSubviews()
        UIView.animate(withDuration: 0.01) {
            self.parentView.transform = CGAffineTransform(translationX: 0, y: self.view.frame.height)
            self.view.layoutIfNeeded()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            self.appearAnimation()
        }
    }
}

extension NextViewController {
    
    func addGestures() {
        panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(panGestureAction(_:)))
        parentView.addGestureRecognizer(panGestureRecognizer!)
    }
    
    func removeGustures() {
        if panGestureRecognizer != nil {
            parentView.removeGestureRecognizer(panGestureRecognizer!)
        }
    }
    
    func appearAnimation() {
        UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.parentView.layer.position.y = self.originalPosition.y
            self.parentView.transform = .identity
            self.view.layoutIfNeeded()
        }) { (finished) in
        }
    }
    
    func disappearAnimation() {
        allowDrag = false
        UIView.animate(withDuration: 0.5) {
            self.blurBackgroundView.alpha = 0
            self.parentView.transform = CGAffineTransform(translationX: 0, y: self.view.frame.height)
            self.view.layoutIfNeeded()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.dismiss(animated: false, completion: nil)
        }
    }
    
    @objc func panGestureAction(_ panGesture: UIPanGestureRecognizer) {
        if allowDrag {
            if parentView.frame.minY > (view.frame.height/2) {
                disappearAnimation()
            } else {
                let translation = panGesture.translation(in: view)
                if panGesture.state == .began {
                    originalPosition = parentView.center
                    originalFrame = parentView.frame
                    currentPositionTouched = panGesture.location(in: parentView)
                } else if panGesture.state == .changed {
                    if parentView.frame.minY >= originalFrame.minY {
                        parentView.frame.origin = CGPoint(x: originalPosition!.x - (self.originalFrame.width/2), y: translation.y + (self.originalFrame.height/4))
                    } else {
                        allowDrag = false
                        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.9, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                            self.parentView.center = self.originalPosition!
                            self.parentView.transform = .identity
                            self.view.layoutIfNeeded()
                        }, completion: { _ in
                            self.allowDrag = true
                        })
                    }
                } else if panGesture.state == .ended {
                    let velocity = panGesture.velocity(in: parentView)
                    if velocity.y >= originalFrame.minY {
                        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                            self.parentView.frame.origin = CGPoint(
                                x: self.originalPosition!.x - (self.originalFrame.width/2),
                                y: self.parentView.frame.size.height
                            )
                        }, completion: { (isCompleted) in
                        })
                        if velocity.y > view.frame.height / 1.5 {
                            self.disappearAnimation()
                        }
                    } else {
                        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                            self.parentView.center = self.originalPosition!
                        }, completion: nil)
                    }
                }
            }
        }
    }
}
